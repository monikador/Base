package KlasaAbstrakcyjna;

public class Ptaszek extends Zwierzatko {
    @Override
    public void poruszajSie() {
        System.out.println("Latam");
    }

    @Override
    public void wypiszPrzsmak() {
        System.out.println("Lubie ziarna");

    }
}
