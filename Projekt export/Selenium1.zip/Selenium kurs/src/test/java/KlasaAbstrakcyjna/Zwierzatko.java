package KlasaAbstrakcyjna;

public abstract class Zwierzatko {

    public String nazwa ="Ssak";

    public abstract void poruszajSie();
    public abstract void wypiszPrzsmak();
    public void napijSieWody(){
        System.out.println("Pije wode");
    }


}
