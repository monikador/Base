package KlasaAbstrakcyjna;

public class Pies extends Zwierzatko{
    @Override
    public void poruszajSie() {
        System.out.println("Biegam");
    }

    @Override
    public void wypiszPrzsmak() {
        System.out.println("Lubie kosci");

    }
}
