import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class OurFirstTest {
    //coś tam sobie piszę
/*
mvn test
cos
sobie
pisze
2
 */
   @Test
    public void sayHallo()
    {
        System.out.println("Witam Cie w kursie Selenium");
    }
}

